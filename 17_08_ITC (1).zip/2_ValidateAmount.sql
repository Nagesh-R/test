USE [welcomgroup]
GO

/****** Object:  StoredProcedure [hotels].[SP_ValidateAmount]    Script Date: 08/16/2016 11:12:35 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[hotels].[SP_ValidateAmount]') AND type in (N'P', N'PC'))
DROP PROCEDURE [hotels].[SP_ValidateAmount]
GO

USE [welcomgroup]
GO

/****** Object:  StoredProcedure [hotels].[SP_ValidateAmount]    Script Date: 08/16/2016 11:12:35 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Description:	< Before making payment validating the amount
-- for non opera hotels >
-- =============================================
CREATE PROCEDURE [hotels].[SP_ValidateAmount] 
	@bookingId int
AS
BEGIN
	SET NOCOUNT ON;
	-- variables to select the details from ReservationDetails using bookingId
	Declare @noOfRooms numeric(18,0),@noOfAdults numeric(18,0),@checkInDate datetime,@checkOutDate datetime,
	@hotelId varchar(20),@roomId numeric(18,0),@planId numeric(18,0)
	
	
	Select @noOfRooms=Number_Of_Rooms,@noOfAdults=Number_Of_Adults,@checkInDate=Checkin_Date,@checkOutDate=Checkout_Date,
	@hotelId=Hotel_Id,@roomId=Room_Id,@planId=Plan_Id from ReservationDetails where Booking_Id = @bookingId
	
	Declare @taxType varchar(20)
	Select @taxType = UPPER(tax_type) from w_hotel where id_hotel=@hotelId
	
	Declare @tempCheckInDate datetime
	Set @tempCheckInDate = @checkInDate
	
	CREATE TABLE #temp_rate
	(
	  amt_rspax1 numeric(18,2),amt_rspax2 numeric(18,2),flg_redemption varchar(1),redemptionType varchar(1),
	  DepositType varchar(1),DepositValue int,number_of_rooms int, number_of_adults int,curr_date datetime,
	  points numeric(18,0)
	)
	
	-- If @planId is independent  
	IF EXISTS(Select bp.id_plan from b_plan bp inner join b_ratecategory brc on bp.rate_code = brc.rate_code
	          inner join b_ratecategory_date brd on brc.id_ratecategory = brd.id_ratecategory_date           
	          where bp.id_hotel = @hotelId and bp.id_plan = @planId and brd.Flg_openstatus = 'O' and 
	          brd.Date_planstatus = @tempCheckInDate)
	begin          
		while(@tempCheckInDate < @checkOutDate)
		begin
		     Insert into #temp_rate
			 (amt_rspax1,amt_rspax2,flg_redemption,redemptionType,DepositType,DepositValue,curr_date) 
			 Select bpr.amt_rspax1,bpr.amt_rspax2,bp.flg_redemption,bp.redemptionType,bp.DepositType,bp.DepositValue,CONVERT(DATE,@tempCheckInDate)
			 from b_plan_rate bpr inner join b_plan bp on bpr.id_plan = bp.id_plan and bpr.id_hotel = bp.id_hotel
			 inner join b_ratecategory brc on bp.rate_code = brc.rate_code inner join b_ratecategory_date brd on 
			 brc.id_ratecategory = brd.id_ratecategory_date where brd.Date_planstatus=@tempCheckInDate
			 and @tempCheckInDate between bpr.date_startocc and bpr.date_endocc
			 and brd.Flg_openstatus = 'O' and brd.id_hotel=@hotelId and bpr.id_room = @roomId
			 and bp.soft_delete = 'N'
			 
			 set @tempCheckInDate = DATEADD(DAY,1,@tempCheckInDate)
		end
    end
    ELSE IF EXISTS(Select id_plan from b_plan where id_hotel = @hotelId and id_plan = @planId and DiscountValue is not null)
	begin 
	    declare @DiscountSign varchar(1)
		declare @DiscountValue numeric(18,2)
		declare @DiscountType varchar(1)
		declare @amtRsPax1 numeric(18,2)
		declare @amtRsPax2 numeric(18,2)
		declare @amountPax1 numeric(18,2)
		declare @amountPax2 numeric(18,2) 
		declare @DepositType varchar(1)
		declare @DepositValue int
		Declare @flgRedemption varchar(1)
		Declare @redemptionType varchar(1)
		
		Select @DiscountSign=DiscountSign, @DiscountValue=DiscountValue, @DiscountType=DiscountType from b_plan where id_hotel = @hotelId and id_plan = @planId  
		
		while(@tempCheckInDate < @checkOutDate)
		begin
			 Select @amtRsPax1=bpr.amt_rspax1,@amtRsPax2=bpr.amt_rspax2,@DepositType=DepositType,@DepositValue=DepositValue
			 ,@flgRedemption=bp.flg_redemption,@redemptionType = bp.redemptionType from b_plan_rate bpr
			 inner join b_plan bp on bpr.id_plan = bp.id_plan inner join b_ratecategory brc on 
			 bp.rate_code = brc.rate_code inner join b_ratecategory_date brd on 
			 brc.id_ratecategory = brd.id_ratecategory_date where brd.Date_planstatus=@tempCheckInDate 
			 and @tempCheckInDate between bpr.date_startocc and bpr.date_endocc
			 and brd.Flg_openstatus = 'O' and brd.id_hotel=@hotelId and bpr.id_room = @roomId
			 
			IF(@DiscountType = 'P')
			BEGIN
				IF(@DiscountSign = '-')
				begin
					SET @amountPax1 = @amtRsPax1 - (@DiscountValue/100)*@amtRsPax1
					SET @amountPax2 = @amtRsPax2 - (@DiscountValue/100)*@amtRsPax2
					
				END
				ELSE
				BEGIN
					SET @amountPax1 = @amtRsPax1 + (@DiscountValue/100)*@amtRsPax1
					SET @amountPax2 = @amtRsPax2 + (@DiscountValue/100)*@amtRsPax2
					
				END
			END
			ELSE
			BEGIN
				IF(@DiscountSign = '-')
				begin
					SET @amountPax1 = @amtRsPax1 - @DiscountValue
					SET @amountPax2 = @amtRsPax2 - @DiscountValue
					
				END
				ELSE
				BEGIN
					SET @amountPax1 = @amtRsPax1 + @DiscountValue
					SET @amountPax2 = @amtRsPax2 + @DiscountValue
					
				END
			END 
			
			INSERT INTO #temp_rate
			(amt_rspax1,amt_rspax2,DepositType,DepositValue,flg_redemption,redemptionType,curr_date)
			VALUES				   
			(@amountPax1,@amountPax2,@DepositType,@DepositValue,@flgRedemption,@redemptionType,CONVERT(DATE,@tempCheckInDate))
						
			 set @tempCheckInDate = DATEADD(DAY,1,@tempCheckInDate)
		end
    end
    ELSE 
    begin
        while(@tempCheckInDate < @checkOutDate)
		begin
			Insert into #temp_rate
			(amt_rspax1,amt_rspax2,flg_redemption,redemptionType,DepositType,DepositValue,curr_date,points) 
			 Select bpr.amt_rspax1,bpr.amt_rspax2,bp.flg_redemption,bp.redemptionType,bp.DepositType,bp.DepositValue,CONVERT(DATE,@tempCheckInDate) 
			,bpr.points from b_plan_rate bpr inner join b_plan bp on bpr.id_plan = bp.id_plan 
			where bpr.id_plan = @planId and bp.id_hotel = @hotelId and bpr.id_room = @roomId
			and @tempCheckInDate between bpr.date_startocc and bpr.date_endocc
            
            set @tempCheckInDate = DATEADD(DAY,1,@tempCheckInDate)
        end 
    end 
    
    Update #temp_rate SET number_of_rooms = @noOfRooms,number_of_adults = @noOfAdults
    
    CREATE TABLE #temp_tax
	(service_tax numeric(18,2),luxury_tax numeric(18,2),vat numeric(18,2),
	 taxType varchar(20),rack_amt_rspax1 numeric(18,2),rack_amt_rspax2 numeric(18,2),tax_date datetime)
	
	set @tempCheckInDate = CONVERT(DATE,@checkInDate)  
	while(@tempCheckInDate < @checkOutDate)
	begin
	   Insert into #temp_tax 
	   Select bt.service_tax,bt.luxury_tax,bt.vat
	   ,case when @taxType = 'R' then 'RACK' else 'CHARGED' end as tax_type,bpr.amt_rspax1 as rack_rspax1,
	   bpr.amt_rspax2  as rack_rspax2,CONVERT(DATE,@checkInDate)
	   from b_tax_detail bt left outer join b_ratecategory br on bt.rate_code = br.rate_code
	   left outer join b_plan bp on br.rate_code = bp.rate_code 
	   left outer join b_plan_rate bpr on bp.id_plan = bpr.id_plan
	   where bt.id_hotel=@hotelId and @checkInDate between bt.start_date and bt.end_date
	   
	    
	 Set @tempCheckInDate = DATEADD(DAY,1,@tempCheckInDate)
	  
	end 
    
    Select * from #temp_rate tr inner join #temp_tax td on tr.curr_date = td.tax_date 
   
    Select badd.amount,badd.tax_amount,rb.quantity,badd.is_point from b_add_on_detail badd inner join r_booking_add_on_details rb
    on badd.id_add_on = rb.add_on_code where rb.booking_id = @bookingId
    
END

GO


