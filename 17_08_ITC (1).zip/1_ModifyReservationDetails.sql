USE [welcomgroup]
GO

/****** Object:  StoredProcedure [hotels].[SP_ModifyReservationDetails]    Script Date: 08/16/2016 11:11:25 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[hotels].[SP_ModifyReservationDetails]') AND type in (N'P', N'PC'))
DROP PROCEDURE [hotels].[SP_ModifyReservationDetails]
GO

USE [welcomgroup]
GO

/****** Object:  StoredProcedure [hotels].[SP_ModifyReservationDetails]    Script Date: 08/16/2016 11:11:25 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE procedure [hotels].[SP_ModifyReservationDetails] 
	@guestTitle [varchar](100),
	@guestFirstName [varchar](100),
	@guestLastName [varchar](100),
	@guestAddress1 [varchar](100),
	@guestAddress2 [varchar](100),
	@guestPhoneNumber [varchar](20),
	@guestEmailId [varchar](50),
	@city [varchar](40),
	@state [varchar](40),
	@country [varchar](40),
	@pinCode [varchar](30),
	@bookingId numeric(18,0),
	@fbhandle [varchar](50),
	@twhandle [varchar](50),
	@Instahandle [varchar](50),
	@company [varchar](50),
	@arrivalFlightNumber varchar(30),
	@airportArrivalTime smalldatetime,
	@arrivalAirportName varchar(70),
	@departureFlightNumber varchar(30),
	@airportDepartureTime smalldatetime,
	@departureAirportName varchar(70)
	AS
UPDATE ReservationDetails
SET Guest_Title=@guestTitle,Guest_First_Name=@guestFirstName, Guest_Last_Name=@guestLastName, Guest_Address1=@guestAddress1, Guest_Address2=@guestAddress2, Guest_Phone_Number=@guestPhoneNumber, Guest_Email_Id=@guestEmailId,
City=@city,State=@state,Country=@country,guest_country=@country
,guest_state=@state,guest_city=@city,
guest_pincode=@pinCode,
guest_fbhandle=@fbhandle,guest_twhandle=@twhandle,guest_instahandle=@Instahandle,guest_company=@company
,Flight_Number_Arrival=@arrivalFlightNumber,Arrival_Time=@airportArrivalTime,Airport_Name_Arrival=@arrivalAirportName
 ,Flight_Number_Departure=@departureFlightNumber,Departure_Time=@airportDepartureTime,Airport_Name_Departure=@departureAirportName,
 amendment_date = getdate()
WHERE Booking_Id=@bookingId
GO


