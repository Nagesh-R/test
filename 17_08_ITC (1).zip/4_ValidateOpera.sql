USE [welcomgroup]
GO

/****** Object:  StoredProcedure [hotels].[SP_ValidateOperaAmount]    Script Date: 08/17/2016 14:44:47 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[hotels].[SP_ValidateOperaAmount]') AND type in (N'P', N'PC'))
DROP PROCEDURE [hotels].[SP_ValidateOperaAmount]
GO

USE [welcomgroup]
GO

/****** Object:  StoredProcedure [hotels].[SP_ValidateOperaAmount]    Script Date: 08/17/2016 14:44:47 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Description:	<To validate amount before payment for opera hotels>
-- =============================================
CREATE PROCEDURE [hotels].[SP_ValidateOperaAmount] 
	@bookingId numeric(18,0)
AS
BEGIN
	
	SET NOCOUNT ON;
    
    Select OWS_ConfirmationID,hotel_path,Hotel_Code,Rate_Plan_Code,Plan_Type from [dbo].[ReservationDetails] where Booking_Id = @bookingId
    
END

GO


