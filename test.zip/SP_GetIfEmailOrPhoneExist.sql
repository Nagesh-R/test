USE [welcomgroup]
GO
/****** Object:  StoredProcedure [hotels].[SP_GetIfEmailOrPhoneExist]    Script Date: 01/25/2016 11:55:08 ******/
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID('[hotels].[SP_GetIfEmailOrPhoneExist]'))
BEGIN
    DROP PROCEDURE [hotels].[SP_GetIfEmailOrPhoneExist]
END

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [hotels].[SP_GetIfEmailOrPhoneExist]    Script Date: 10/14/2015 7:47:30 ******/

CREATE Procedure [hotels].[SP_GetIfEmailOrPhoneExist]
@userId varchar(50),@mobileNumber varchar(50)

AS

SELECT * FROM [welcomgroup].[dbo].[Register] WHERE [Email_Id] = @userId OR [Mobile_Number]=@mobileNumber