USE [welcomgroup]
GO

/****** Object:  StoredProcedure [hotels].[SP_GetIfVerificationLinkExist]    Script Date: 01/23/2016 14:57:26 ******/
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID('[hotels].[SP_GetIfVerificationLinkExist]'))
BEGIN
    DROP PROCEDURE [hotels].[SP_GetIfVerificationLinkExist]
END
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [hotels].[SP_GetIfVerificationLinkExist]    Script Date: 10/26/2015 16:18:13 ******/

CREATE Procedure [hotels].[SP_GetIfVerificationLinkExist]
@verificationLink varchar(100)

AS

SELECT * FROM [welcomgroup].[dbo].[Register] WHERE [Verification_Link] = @verificationLink
GO


