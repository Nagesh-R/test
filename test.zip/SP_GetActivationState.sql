USE [welcomgroup]
GO

/****** Object:  StoredProcedure [hotels].[SP_GetActivationState]    Script Date: 01/23/2016 15:01:22 ******/
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID('[hotels].[SP_GetActivationState]'))
BEGIN
    DROP PROCEDURE [hotels].[SP_GetActivationState]
END

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [hotels].[SP_GetActivationState]    Script Date: 10/26/2015 16:18:13 ******/

CREATE Procedure [hotels].[SP_GetActivationState]
@emailId varchar(50)

AS

SELECT [Verification_Flag],DATEDIFF(MINUTE, date_time, GETDATE()) AS MinuteDiff FROM [welcomgroup].[dbo].[Register] WHERE [Email_Id] = @emailId

GO


