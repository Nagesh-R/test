USE [welcomgroup]
GO

/****** Object:  StoredProcedure [hotels].[SP_UpdateNewVerificationLink]    Script Date: 01/23/2016 15:03:41 ******/
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID('[hotels].[SP_UpdateNewVerificationLink]'))
BEGIN
    DROP PROCEDURE [hotels].[SP_UpdateNewVerificationLink]
END

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE Procedure [hotels].[SP_UpdateNewVerificationLink]
@emailId varchar(50),@verificationLink varchar(100)
AS

UPDATE [welcomgroup].[dbo].[Register] SET [Verification_Link]=@verificationLink,[date_time]=GETDATE() WHERE [Email_Id]=@emailId;

GO


