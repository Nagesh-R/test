USE [welcomgroup]
GO

/****** Object:  StoredProcedure [hotels].[SP_UpdateActivationState]    Script Date: 01/23/2016 15:02:40 ******/
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID('[hotels].[SP_UpdateActivationState]'))
BEGIN
    DROP PROCEDURE [hotels].[SP_UpdateActivationState]
END

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [hotels].[SP_UpdateActivationState]   Script Date: 10/26/2015 16:18:13 ******/

CREATE Procedure [hotels].[SP_UpdateActivationState]
@emailId varchar(50),@verfiStatus varchar(10)

AS

UPDATE [welcomgroup].[dbo].[Register] SET [Verification_Flag] = @verfiStatus WHERE [Email_Id] = @emailId
GO


