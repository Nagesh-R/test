USE [welcomgroup]
GO

/****** Object:  StoredProcedure [hotels].[SP_GetOnlineNewUserDetails]    Script Date: 01/23/2016 15:00:00 ******/
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID('[hotels].[SP_GetOnlineNewUserDetails]'))
BEGIN
    DROP PROCEDURE [hotels].[SP_GetOnlineNewUserDetails]
END
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE Procedure [hotels].[SP_GetOnlineNewUserDetails]
@loginId varchar(50),@title varchar(50),@firstName varchar(50),@lastName varchar(50),@gender varchar(50),@address1 varchar(100),@address2 varchar(100),@country varchar(50),@state varchar(50),@city varchar(50),@pincode varchar(20),@compName varchar(50),@emailId varchar(50),@countryCode varchar(20),@mobNumber varchar(20),@facebook varchar(50),@twitter varchar(50),@instagram varchar(50),@dob DATE,@maritalStatus varchar(10),@password varchar(45),@verificationLink varchar(100)
AS

INSERT INTO [welcomgroup].[dbo].[Register] ([Login_Id],[Title],[First_Name],[Last_Name],[Gender],[Address_Line1],[Address_Line2],[Country],[State],[City],[Pincode],[Company_Name],[Email_Id],[Country_Code],[Mobile_Number],[Facebook_Id],[Twitter_Id],[Instagram],[Date_of_Birth],[Marital_Status],[Password],[Verification_Link],[date_time])
VALUES (@loginId,@title,@firstName,@lastName,@gender,@address1,@address2,@country,@state,@city,@pincode,@compName,@emailId,@countryCode,@mobNumber,@facebook,@twitter,@instagram,@dob,@maritalStatus,@password,@verificationLink,getdate());
GO


